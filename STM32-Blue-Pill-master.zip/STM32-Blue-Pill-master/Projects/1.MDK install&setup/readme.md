# MDK5 install & setup
-----



# Tips
* keil5中文乱码   
Edit->Configuration->Encoding修改编码格式为gb2312(simplified)即可
* 代码格式化  
[在Keil5中使用代码格式化工具Astyle](https://blog.csdn.net/u010160335/article/details/78587411)  

# 参考链接
[MDK5下载地址](http://www2.keil.com/mdk5/)  